﻿using Covid19RegPro.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Covid19RegPro.Models
{
	public class RegFormViewModel
	{
		public int Id { get; set; }
		public string TypeName { get; set; }
		public string NID { get; set; }
		public int dateDay { get; set; }
		public string dateMonth { get; set; }
		public int year { get; set; }
		public DateTime? regDate { get; set; }
		public string nameBn { get; set; }
		public string nameEn { get; set; }
		public string mobile { get; set; }
		public int? divisionId { get; set; }

		public int? districtId { get; set; }

		public int? thanaId { get; set; }

		public int? unionId { get; set; }

		public int? centerId { get; set; }

		public int? status { get; set; } //1=vaccinated

		public IEnumerable<Division> divisions { get; set; }
		public IEnumerable<District> districts { get; set; }
		public IEnumerable<Thana> thanas { get; set; }
		public IEnumerable<Union> unions { get; set; }
		public IEnumerable<Center> centers { get; set; }
		public IEnumerable<RegType> regTypes { get; set; }

		public IEnumerable<RegForm> regForms { get; set; }
	}
}
