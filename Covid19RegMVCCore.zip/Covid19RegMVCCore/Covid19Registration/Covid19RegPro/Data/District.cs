﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Covid19RegPro.Data
{
	public class District
	{
		public int Id { get; set; }
		public string Name { get; set; }

		public int? divisionId { get; set; }
		public Division division { get; set; }
	}
}
