﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Covid19RegPro.Data
{
	public class RegForm
	{
		public int Id { get; set; }
		public string TypeName { get; set; }
		public string NID { get; set; }
		public int dateDay { get; set; }
		public string dateMonth { get; set; }
		public int year { get; set; }
		public DateTime? regDate { get; set; }
		public string nameBn { get; set; }
		public string nameEn { get; set; }
		public string mobile { get; set; }
		public int? divisionId { get; set; }
		public Division division { get; set; }

		public int? districtId { get; set; }
		public District district { get; set; }

		public int? thanaId { get; set; }
		public Thana thana { get; set; }

		public int? unionId { get; set; }
		public Union union { get; set; }

		public int? centerId { get; set; }
		public Center center { get; set; }

		public int? status { get; set; } //1=vaccinated
	}
}
