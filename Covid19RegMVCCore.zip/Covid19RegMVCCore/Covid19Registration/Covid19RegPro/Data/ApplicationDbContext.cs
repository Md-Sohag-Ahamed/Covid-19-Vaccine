﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Covid19RegPro.Data
{
	public class ApplicationDbContext : IdentityDbContext
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
			: base(options)
		{
		}

		public DbSet<Division> divisions { get; set; }
		public DbSet<District> districts { get; set; }
		public DbSet<Thana> thanas { get; set; }
		public DbSet<Union> unions { get; set; }
		public DbSet<Center> centers { get; set; }
		public DbSet<RegForm> regForms { get; set; }
		public DbSet<RegType> regTypes { get; set; }
	}
}
