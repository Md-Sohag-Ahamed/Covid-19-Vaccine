﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Covid19RegPro.Migrations
{
    public partial class init2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Type",
                table: "regForms");

            migrationBuilder.AddColumn<string>(
                name: "TypeName",
                table: "regForms",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "regTypes",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_regTypes", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "regTypes");

            migrationBuilder.DropColumn(
                name: "TypeName",
                table: "regForms");

            migrationBuilder.AddColumn<string>(
                name: "Type",
                table: "regForms",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
