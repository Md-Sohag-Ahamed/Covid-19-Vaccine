﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Covid19RegPro.Migrations
{
    public partial class init3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "division",
                table: "districts");

            migrationBuilder.CreateIndex(
                name: "IX_districts_divisionId",
                table: "districts",
                column: "divisionId");

            migrationBuilder.AddForeignKey(
                name: "FK_districts_divisions_divisionId",
                table: "districts",
                column: "divisionId",
                principalTable: "divisions",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_districts_divisions_divisionId",
                table: "districts");

            migrationBuilder.DropIndex(
                name: "IX_districts_divisionId",
                table: "districts");

            migrationBuilder.AddColumn<string>(
                name: "division",
                table: "districts",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
