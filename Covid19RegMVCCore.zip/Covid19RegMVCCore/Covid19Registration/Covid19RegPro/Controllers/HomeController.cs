﻿using Covid19RegPro.Data;
using Covid19RegPro.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Covid19RegPro.Controllers
{
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;
		private readonly ApplicationDbContext _context;

		public HomeController(ILogger<HomeController> logger, ApplicationDbContext _context)
		{
			_logger = logger;
			this._context = _context;
		}

		public async Task<IActionResult> Index()
		{
			var model = new RegFormViewModel
			{
				regTypes = await _context.regTypes.ToListAsync(),
				divisions = await _context.divisions.ToListAsync(),
				districts = await _context.districts.ToListAsync(),
				thanas = await _context.thanas.ToListAsync(),
				unions = await _context.unions.ToListAsync(),
				centers = await _context.centers.ToListAsync()
			};
			return View(model);
		}
		[HttpPost]
		public async Task<IActionResult> Index(RegFormViewModel model)
		{
			var data = new RegForm
			{
				Id = 0,
				TypeName = model.TypeName,
				NID = model.NID,
				dateDay = model.dateDay,
				dateMonth = model.dateMonth,
				year = model.year,
				regDate = DateTime.Now,
				nameBn = model.nameBn,
				nameEn = model.nameEn,
				mobile = model.mobile,
				divisionId = model.divisionId,
				districtId = model.districtId,
				thanaId = model.thanaId,
				unionId = model.unionId,
				centerId = model.centerId,
				status = 0
			};
			_context.Add(data);
			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}
		public async Task<IActionResult> GetRegList()
		{
			var model = new RegFormViewModel
			{
				regForms = await _context.regForms.Include(x => x.center).ToListAsync()
			};
			return View(model);
		}
		public async Task<IActionResult> GetDistrictsByDivisionId(int? id)
		{
			var data = await _context.districts.Where(x => x.divisionId == id).ToListAsync();
			return Json(data);
		}
		public async Task<IActionResult> GetThanasByDistrictId(int? id)
		{
			var data = await _context.thanas.Where(x => x.districtId == id).ToListAsync();
			return Json(data);
		}
		public async Task<IActionResult> GetUnionsByThanaId(int? id)
		{
			var data = await _context.unions.Where(x => x.thanaId == id).ToListAsync();
			return Json(data);
		}
		public async Task<IActionResult> GetCentersByUnionId(int? id)
		{
			var data = await _context.centers.Where(x => x.unionId == id).ToListAsync();
			return Json(data);
		}

		public async Task<IActionResult> GetVaccinated(int? id)
		{
			var data = await _context.regForms.Where(x => x.Id == id).FirstOrDefaultAsync();
			if (data.status == 0)
			{
				data.status = 1;
			}
			else
			{
				data.status = 0;
			}
			
			_context.Update(data);
			await _context.SaveChangesAsync();
			return Json("ok");
		}


















		public IActionResult Privacy()
		{
			return View();
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}
